﻿=== Agumon_Digimon Cursor Set ===

By: Clavier141

Download: http://www.rw-designer.com/cursor-set/agumon-digimon

Author's description:

A set of cursors of Agumon from the popular TV series Digimon: Digital Monsters. Several cursors in this set are animated. Credit for sprites goes to Fenrir's Sprite Domain where they have sprites from the Wonderswan digimon games.

Send me any requests for digimon cursors you'd like to see in the reviews and I'll see if I can do them.

Also, please check out Operation Decode, a petition to localize Digimon World: Re:Digitize Decode for 3DS in US and EU. They're on twitter @OperationDecode or you can check the petition page on Change.org http://www.change.org/en-GB/petitions/namco-bandai-games-europe-america-localize-digimon-world-re-digitize-decode-for-3ds

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.